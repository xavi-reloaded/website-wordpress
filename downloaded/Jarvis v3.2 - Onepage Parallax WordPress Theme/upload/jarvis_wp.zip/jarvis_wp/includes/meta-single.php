<p class="meta-date">
  <?php _e('Posted on ', 'rocknrolla'); the_time(get_option('date_format')); ?> <?php _e('in ', 'rocknrolla'); the_category(', '); ?>
</p>
 