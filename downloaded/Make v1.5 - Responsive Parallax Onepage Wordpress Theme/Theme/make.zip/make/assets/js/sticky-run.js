(function($) {
"use strict";

$(document).ready(function(){
		$("#main_menu").sticky({topSpacing:0});
	});
})(jQuery);